package com.factory.appraisal.vehiclesearchapp.services;

import com.factory.appraisal.vehiclesearchapp.persistence.dto.AppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.persistence.dto.ConfigurationCodes;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface EConfigurationCodesService {
    public ConfigurationCodes addConfigCode(ConfigurationCodes configurationCodes);
    List<ConfigurationCodes> GetConfigCodes(Integer pageNo, Integer pageSize);
    ConfigurationCodes updateConfigCodes(long codeId,ConfigurationCodes configurationCodes);
    String deleteConfigCodes(long codeId);

}
