package com.factory.appraisal.vehiclesearchapp.services;
//Author:Rupesh khade
import com.factory.appraisal.vehiclesearchapp.persistence.model.ESignDet;
import com.factory.appraisal.vehiclesearchapp.repository.ESignDetRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ESignDetServiceImpl implements ESignDetService{
    @Autowired
    private ESignDetRepo eSignDetRepo;
    @Override
    public ESignDet addESignDet(ESignDet eSignDet) {
        return eSignDetRepo.save(eSignDet);
    }
}
