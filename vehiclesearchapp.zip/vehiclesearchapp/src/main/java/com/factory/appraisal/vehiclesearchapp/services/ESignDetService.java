package com.factory.appraisal.vehiclesearchapp.services;

import com.factory.appraisal.vehiclesearchapp.persistence.model.ESignDet;

public interface ESignDetService {
    public ESignDet addESignDet(ESignDet eSignDet);
}
